<?php
 
class Authentication
{
	public $auth_id;
    public $username;
    public $password;
    public $name;
    public $role_id;
    public $deny_access;

    // constructor
    function __construct() 
    {

    }
 
    // destructor
    function __destruct() 
    {
         
    }
}
 
?>