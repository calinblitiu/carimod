<?php
 
class Flag
{
	public $review_id;
    public $review;
    public $user_id;
    public $created_at;
    public $updated_at;


    // constructor
    function __construct() 
    {

    }
 
    // destructor
    function __destruct() 
    {
         
    }
}
 
?>