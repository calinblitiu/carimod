<?php
 
class ItemSold
{
	public $item_sold_id;
    public $item_id;

    public $created_at;
    public $updated_at;
    public $is_deleted;


    // constructor
    function __construct() 
    {

    }
 
    // destructor
    function __destruct() 
    {
         
    }
}
 
?>