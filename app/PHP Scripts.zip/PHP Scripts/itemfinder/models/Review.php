<?php
 
class Review
{
	public $review_id;
    public $review;
    public $parent_user_id; 
    public $user_id;
    public $created_at;
    public $updated_at;


    // constructor
    function __construct() 
    {

    }
 
    // destructor
    function __destruct() 
    {
         
    }
}
 
?>