<?php

  require '../header_rest.php';
  $controllerRest = new ControllerRest();
  $controllerUser = new ControllerUser();

  if(empty($_GET['store_id']) )
  {
        $json = "{
                \"status\" : {
                              \"status_code\" : \"3\",
                              \"status_text\" : \"Invalid Access.\"
                            }
                }";

        echo $json;
  }

  else {

    $store_id = $_GET['store_id'];
    $count = $_GET['count'];

    $resultReviews = $controllerRest->getResultReviewsCount($count, $store_id);

      // header ("content-type: text/json");
      // header("Content-Type: application/text; charset=ISO-8859-1");
      echo "{";
                $no_of_rows = $resultReviews->rowCount();
                $total_row_count = $controllerRest->getResultReviewsTotalCount($store_id);

                $json = " \"request_count\" : \"$count\", \"return_count\" : \"$no_of_rows\", \"total_row_count\" : \"$total_row_count\", ";

                echo $json;

                // REVIEWS
                echo "\"reviews\" : [";
                
                $ind = 0;
                $count = $resultReviews->columnCount();
                foreach ($resultReviews as $row) 
                {
                    echo "{";
                    $inner_ind = 0;
                    foreach ($row as $columnName => $field) 
                    {

                        $val = trim(strip_tags($field));
                        if(!is_numeric($columnName)) {
                            echo "\"$columnName\" : \"$val\"";

                            if($inner_ind < $count - 1)
                              echo ",";

                            ++$inner_ind;
                        }
                    }

                    if($count > $inner_ind) {
                        echo "\"slug\" : \"slug\"";
                    }

                    echo "}";

                    if($ind < $no_of_rows - 1)
                      echo ",";

                    ++$ind;
                }
                echo "]";

      echo "}";

    
  }
?>